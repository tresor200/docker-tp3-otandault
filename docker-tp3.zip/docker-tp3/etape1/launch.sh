#!/usr/bin/env bash
set -euo pipefail

NAME_HTTP=http
NAME_PHP=script
NET=tp3-net

# Clean previous runs (ignore errors)
docker rm -f "$NAME_HTTP" 2>/dev/null || true
docker rm -f "$NAME_PHP" 2>/dev/null || true

# Create network if missing
docker network inspect "$NET" >/dev/null 2>&1 || docker network create "$NET"

# Start PHP-FPM container
docker run -d --name "$NAME_PHP" --network "$NET"       -v "$(pwd)/src":/app       php:8.2-fpm

# Start Nginx container
docker run -d --name "$NAME_HTTP" --network "$NET" -p 8080:80       -v "$(pwd)/src":/app       -v "$(pwd)/config/nginx/default.conf":/etc/nginx/conf.d/default.conf:ro       nginx:1.27
echo "Step 1 running: http://localhost:8080"
