<html>
	<body>
	<?php phpinfo(); ?>
	</body>
</html>
