# Docker TP3 — Structure complète

## Étape 0
- `git init` dans `docker-tp3`
- Chaque étape dispose de son dossier `etapeX` avec un `launch.sh`

## Étape 1 (Nginx + PHP-FPM)
```bash
cd etape1
chmod +x launch.sh
./launch.sh
# Tester: http://localhost:8080/
```

## Étape 2 (Nginx + PHP-FPM + MariaDB)
```bash
cd etape2
chmod +x launch.sh
./launch.sh
# Tester: http://localhost:8080/ et http://localhost:8080/test.php
```

## Étape 3 (Docker Compose)
```bash
cd etape3
chmod +x launch.sh
./launch.sh
# Tester: http://localhost:8080/ et http://localhost:8080/test.php
```

> Pense à faire `docker rm -f http script data` entre les étapes si besoin.
