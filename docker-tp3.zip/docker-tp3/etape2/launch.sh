#!/usr/bin/env bash
set -euo pipefail

NAME_HTTP=http
NAME_PHP=script
NAME_DB=data
NET=tp3-net

# Clean previous runs
docker rm -f "$NAME_HTTP" "$NAME_PHP" "$NAME_DB" 2>/dev/null || true

# Create network if missing
docker network inspect "$NET" >/dev/null 2>&1 || docker network create "$NET"

# Build PHP image with mysqli
docker build -t tp3-php ./php

# Start MariaDB (init via /docker-entrypoint-initdb.d)
docker run -d --name "$NAME_DB" --network "$NET"       -e MARIADB_RANDOM_ROOT_PASSWORD=1       -v "$(pwd)/db/init":/docker-entrypoint-initdb.d:ro       mariadb:11

# Start PHP-FPM using custom image
docker run -d --name "$NAME_PHP" --network "$NET"       -v "$(pwd)/src":/app       tp3-php

# Start Nginx
docker run -d --name "$NAME_HTTP" --network "$NET" -p 8080:80       -v "$(pwd)/src":/app       -v "$(pwd)/config/nginx/default.conf":/etc/nginx/conf.d/default.conf:ro       nginx:1.27

echo "Step 2 running: http://localhost:8080 and http://localhost:8080/test.php"
