#!/usr/bin/env bash
set -euo pipefail
docker compose up -d --build
echo "Step 3 running: http://localhost:8080 and http://localhost:8080/test.php"
